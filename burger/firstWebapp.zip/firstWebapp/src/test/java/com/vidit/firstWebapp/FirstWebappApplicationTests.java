package com.vidit.firstWebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstWebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
