package com.vidit.firstWebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstWebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstWebappApplication.class, args);
	}

}
